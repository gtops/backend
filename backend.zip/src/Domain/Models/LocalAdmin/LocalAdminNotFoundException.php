<?php


namespace App\Domain\Models\LocalAdmin;


use PHPUnit\Runner\Exception;

class LocalAdminNotFoundException extends Exception
{

}