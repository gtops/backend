<?php

namespace App\Domain\Models\Role;
use PHPUnit\Runner\Exception;

class RoleNotFoundException extends Exception
{

}