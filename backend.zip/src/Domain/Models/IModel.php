<?php


namespace App\Domain\Models;


interface IModel
{
    public function toArray():array ;
}