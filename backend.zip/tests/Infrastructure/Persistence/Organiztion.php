<?php


class Organiztion extends \Tests\TestCase
{
    private $connection;

    function testAddOrganization()
    {
        $this->assertEquals(1, 1);
    }
}